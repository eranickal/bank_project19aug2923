/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author erani
 */
public class Customer {
    private int CID;
    private String fname;
    private String lname;
    private String email;
    private String phone;
    
    
}
